# Underground Utilities Expert — Deployment Guide

## What you have
A Next.js web app that runs your AI utilities expert. Your Anthropic API key
lives only on the server — it's never exposed in the browser.

---

## Step 1 — Get your Anthropic API key
1. Go to https://console.anthropic.com
2. Sign up or log in
3. Click **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-...`) — save it somewhere safe

---

## Step 2 — Put the code on GitHub
1. Go to https://github.com and create a free account if needed
2. Click **New repository** → name it `utilities-expert` → **Create**
3. Upload all the files from this folder into the repo
   (drag and drop them in the GitHub web interface, or use GitHub Desktop)

---

## Step 3 — Deploy to Vercel (free)
1. Go to https://vercel.com and sign up with your GitHub account
2. Click **Add New Project**
3. Select your `utilities-expert` repository
4. Click **Deploy** — Vercel auto-detects Next.js

---

## Step 4 — Add your API key to Vercel
1. In your Vercel project, go to **Settings → Environment Variables**
2. Add a new variable:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** paste your key from Step 1
3. Click **Save**
4. Go to **Deployments** → click the 3 dots on your latest deploy → **Redeploy**

---

## Step 5 — Add to your phone home screen

**iPhone (Safari):**
1. Open your Vercel URL in Safari
2. Tap the Share button (box with arrow pointing up)
3. Scroll down → tap **Add to Home Screen**
4. Tap **Add** — it now appears as an app icon

**Android (Chrome):**
1. Open your Vercel URL in Chrome
2. Tap the 3-dot menu
3. Tap **Add to Home screen**
4. Tap **Add**

---

## Sharing with your crew
Send anyone the Vercel URL — they can use it in their browser or add it
to their own home screen. No app store, no install required.

---

## Cost estimate
Anthropic charges per token (per word roughly). For typical field use:
- ~100 questions/day = roughly $1–3/month
- Very affordable for a whole crew

---

## Updating the app
To change the AI's knowledge or add quick topics:
- Edit `src/app/api/chat/route.js` (change SYSTEM_PROMPT)
- Edit `src/app/components/ChatApp.js` (change QUICK_TOPICS array)
- Push changes to GitHub → Vercel auto-redeploys in ~1 minute
