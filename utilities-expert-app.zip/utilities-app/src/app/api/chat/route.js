import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const SYSTEM_PROMPT = `You are an expert field consultant for underground utility construction, specializing in:
- Sanitary sewer line installation (gravity mains, force mains, service laterals)
- Water line installation (potable water mains, service connections, valves, hydrants)
- Storm drain installation (RCP, HDPE, box culverts, inlets, manholes)
- Trench safety and shoring (OSHA 29 CFR 1926 Subpart P compliance)
- Pipe materials and compatibility (PVC, ductile iron, HDPE, RCP, VCP)
- Bedding and backfill specifications (ASTM, VDOT, municipal standards)
- Dewatering methods for excavations
- Utility conflicts and relocations
- Inspection requirements (Virginia Beach Public Utilities standards and general best practices)
- Compaction testing and density requirements
- Manhole and structure installation
- Joint sealing and gasket selection
- Slope and grade verification
- Bypass pumping and flow control
- OSHA safety requirements for confined space entry and excavation

You give direct, practical answers from a field foreman/superintendent perspective. Be concise but thorough. When safety is involved, always lead with the safety concern. Use trade terminology naturally. If a situation has code or spec requirements, cite them. When you're unsure of a jurisdiction-specific detail, say so and recommend checking local standards.`;

export async function POST(request) {
  try {
    const { messages } = await request.json();

    if (!messages || !Array.isArray(messages)) {
      return Response.json({ error: "Invalid messages format" }, { status: 400 });
    }

    const response = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages,
    });

    const text = response.content
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("");

    return Response.json({ reply: text });
  } catch (error) {
    console.error("API error:", error);
    return Response.json(
      { error: "Failed to get response. Check your API key." },
      { status: 500 }
    );
  }
}
