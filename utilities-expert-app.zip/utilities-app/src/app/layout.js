export const metadata = {
  title: "Underground Utilities Expert",
  description: "Field AI assistant for sewer, water, and storm drain construction",
  manifest: "/manifest.json",
  themeColor: "#0f1117",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Utilities Expert",
  },
  viewport: {
    width: "device-width",
    initialScale: 1,
    maximumScale: 1,
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="apple-touch-icon" href="/icon-192.png" />
      </head>
      <body style={{ margin: 0, padding: 0, background: "#0f1117" }}>
        {children}
      </body>
    </html>
  );
}
