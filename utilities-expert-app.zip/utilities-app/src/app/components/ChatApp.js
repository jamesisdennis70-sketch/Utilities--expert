"use client";
import { useState, useRef, useEffect } from "react";

const QUICK_TOPICS = [
  { label: "Trench Safety", prompt: "What are the OSHA requirements for trench shoring and sloping in Type B soil at 8 feet deep?" },
  { label: "Pipe Bedding", prompt: "What bedding and backfill spec should I use for 12-inch PVC sewer main under a paved road?" },
  { label: "Manhole Install", prompt: "What's the correct sequence for setting a precast concrete manhole in a sewer line?" },
  { label: "Dewatering", prompt: "We're hitting groundwater at 5 feet in sandy soil. What are my best dewatering options?" },
  { label: "Line & Grade", prompt: "My laser level is reading inconsistent grades. How do I troubleshoot and verify pipe grade in the field?" },
  { label: "Bypass Pumping", prompt: "How do I set up a bypass pump for a live 8-inch sewer main repair?" },
  { label: "Utility Conflict", prompt: "I've uncovered an unmarked water main crossing my sewer trench. What do I do?" },
  { label: "Compaction", prompt: "What compaction requirements apply to backfill under a road for a water main install?" },
];

const styles = {
  app: {
    minHeight: "100vh",
    maxHeight: "100vh",
    background: "#0f1117",
    display: "flex",
    flexDirection: "column",
    fontFamily: "'Inter', system-ui, -apple-system, sans-serif",
    color: "#e2e8f0",
    overflow: "hidden",
  },
  header: {
    background: "#1a1d27",
    borderBottom: "2px solid #f59e0b",
    padding: "12px 16px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexShrink: 0,
  },
  headerLeft: { display: "flex", alignItems: "center", gap: 10 },
  icon: {
    width: 40, height: 40,
    background: "linear-gradient(135deg, #f59e0b, #d97706)",
    borderRadius: 8,
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 20,
  },
  title: { fontWeight: 700, fontSize: 16, color: "#f8fafc", letterSpacing: "-0.2px" },
  subtitle: { fontSize: 11, color: "#94a3b8", marginTop: 2 },
  clearBtn: {
    background: "transparent",
    border: "1px solid #334155",
    borderRadius: 6,
    color: "#94a3b8",
    padding: "5px 10px",
    fontSize: 12,
    cursor: "pointer",
  },
  body: { flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" },
  scrollArea: { flex: 1, overflowY: "auto", padding: "16px" },
  welcomeCard: {
    background: "#1a1d27",
    border: "1px solid #2d3748",
    borderRadius: 12,
    padding: "16px 20px",
    marginBottom: 20,
  },
  welcomeText: { fontSize: 13, color: "#94a3b8", lineHeight: 1.7 },
  sectionLabel: {
    fontSize: 11, fontWeight: 600, letterSpacing: "0.08em",
    color: "#64748b", textTransform: "uppercase", marginBottom: 10,
  },
  grid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 },
  topicBtn: {
    background: "#1a1d27",
    border: "1px solid #2d3748",
    borderRadius: 8,
    color: "#cbd5e1",
    padding: "11px 13px",
    fontSize: 12,
    cursor: "pointer",
    textAlign: "left",
    fontWeight: 500,
  },
  messagesWrap: {
    display: "flex", flexDirection: "column", gap: 14,
    maxWidth: 700, margin: "0 auto", width: "100%",
  },
  msgRow: (role) => ({
    display: "flex",
    flexDirection: role === "user" ? "row-reverse" : "row",
    alignItems: "flex-start",
    gap: 8,
  }),
  avatar: (role) => ({
    width: 30, height: 30, borderRadius: 6, flexShrink: 0,
    background: role === "user" ? "#1e40af" : "linear-gradient(135deg, #f59e0b, #d97706)",
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 14,
  }),
  bubble: (role) => ({
    background: role === "user" ? "#1e3a5f" : "#1a1d27",
    border: `1px solid ${role === "user" ? "#2563eb" : "#2d3748"}`,
    borderRadius: 10,
    padding: "10px 14px",
    maxWidth: "84%",
    fontSize: 14,
    lineHeight: 1.65,
    color: "#e2e8f0",
    whiteSpace: "pre-wrap",
    wordBreak: "break-word",
  }),
  inputArea: {
    background: "#1a1d27",
    borderTop: "1px solid #2d3748",
    padding: "12px 16px 16px",
    flexShrink: 0,
  },
  inputRow: {
    display: "flex", gap: 8, alignItems: "flex-end",
    maxWidth: 700, margin: "0 auto",
  },
  textarea: {
    flex: 1,
    background: "#0f1117",
    border: "1px solid #334155",
    borderRadius: 8,
    color: "#e2e8f0",
    padding: "10px 13px",
    fontSize: 14,
    resize: "none",
    outline: "none",
    fontFamily: "inherit",
    lineHeight: 1.5,
    maxHeight: 110,
    overflowY: "auto",
  },
  sendBtn: (active) => ({
    background: active ? "linear-gradient(135deg, #f59e0b, #d97706)" : "#2d3748",
    border: "none",
    borderRadius: 8,
    color: active ? "#0f1117" : "#64748b",
    width: 42, height: 42,
    cursor: active ? "pointer" : "not-allowed",
    fontSize: 18, fontWeight: 700,
    display: "flex", alignItems: "center", justifyContent: "center",
    flexShrink: 0,
  }),
  disclaimer: {
    fontSize: 10, color: "#475569", textAlign: "center",
    marginTop: 6, maxWidth: 700, margin: "6px auto 0",
  },
};

export default function ChatApp() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const sendMessage = async (text) => {
    const userText = (text || input).trim();
    if (!userText || loading) return;
    setInput("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";

    const newMessages = [...messages, { role: "user", content: userText }];
    setMessages(newMessages);
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: newMessages }),
      });

      const data = await res.json();
      if (data.error) throw new Error(data.error);

      setMessages([...newMessages, { role: "assistant", content: data.reply }]);
    } catch (err) {
      setMessages([...newMessages, {
        role: "assistant",
        content: "⚠️ Error: " + (err.message || "Could not connect. Check your API key in Vercel settings."),
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleInput = (e) => {
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 110) + "px";
  };

  return (
    <div style={styles.app}>
      <style>{`
        @keyframes pulse {
          0%,80%,100%{opacity:.3;transform:scale(.8)}
          40%{opacity:1;transform:scale(1)}
        }
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:5px}
        ::-webkit-scrollbar-track{background:#0f1117}
        ::-webkit-scrollbar-thumb{background:#2d3748;border-radius:3px}
        textarea::placeholder{color:#475569}
      `}</style>

      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.icon}>🔧</div>
          <div>
            <div style={styles.title}>Underground Utilities Expert</div>
            <div style={styles.subtitle}>Sewer · Water · Storm Drain · OSHA Safety</div>
          </div>
        </div>
        {messages.length > 0 && (
          <button style={styles.clearBtn} onClick={() => setMessages([])}>Clear</button>
        )}
      </div>

      {/* Body */}
      <div style={styles.body}>
        {messages.length === 0 ? (
          <div style={styles.scrollArea}>
            <div style={{ maxWidth: 640, margin: "0 auto" }}>
              <div style={styles.welcomeCard}>
                <div style={styles.welcomeText}>
                  Ask any field question — trench safety, pipe specs, grade issues, material conflicts,
                  inspection prep, or crew troubleshooting. You'll get a straight answer from an experienced perspective.
                </div>
              </div>
              <div style={styles.sectionLabel}>Quick Topics</div>
              <div style={styles.grid}>
                {QUICK_TOPICS.map((t) => (
                  <button
                    key={t.label}
                    style={styles.topicBtn}
                    onClick={() => sendMessage(t.prompt)}
                    onMouseEnter={e => e.currentTarget.style.borderColor = "#f59e0b"}
                    onMouseLeave={e => e.currentTarget.style.borderColor = "#2d3748"}
                  >
                    <span style={{ color: "#f59e0b", marginRight: 5 }}>▸</span>{t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div style={styles.scrollArea}>
            <div style={styles.messagesWrap}>
              {messages.map((msg, i) => (
                <div key={i} style={styles.msgRow(msg.role)}>
                  <div style={styles.avatar(msg.role)}>
                    {msg.role === "user" ? "👷" : "🔧"}
                  </div>
                  <div style={styles.bubble(msg.role)}>{msg.content}</div>
                </div>
              ))}
              {loading && (
                <div style={styles.msgRow("assistant")}>
                  <div style={styles.avatar("assistant")}>🔧</div>
                  <div style={{ ...styles.bubble("assistant"), display: "flex", gap: 5, alignItems: "center", padding: "12px 14px" }}>
                    {[0,1,2].map(i => (
                      <div key={i} style={{
                        width: 7, height: 7, borderRadius: "50%", background: "#f59e0b",
                        animation: "pulse 1.2s ease-in-out infinite",
                        animationDelay: `${i * 0.2}s`,
                      }} />
                    ))}
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>
          </div>
        )}

        {/* Input */}
        <div style={styles.inputArea}>
          <div style={styles.inputRow}>
            <textarea
              ref={textareaRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              onInput={handleInput}
              onFocus={e => e.target.style.borderColor = "#f59e0b"}
              onBlur={e => e.target.style.borderColor = "#334155"}
              placeholder="Describe your field situation or ask a question…"
              rows={1}
              style={styles.textarea}
            />
            <button
              style={styles.sendBtn(!!input.trim() && !loading)}
              onClick={() => sendMessage()}
              disabled={!input.trim() || loading}
            >↑</button>
          </div>
          <div style={styles.disclaimer}>
            For field guidance only — always verify against project specs and local standards
          </div>
        </div>
      </div>
    </div>
  );
}
